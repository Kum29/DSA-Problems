/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
int p(int n, int c) {
    if(c==1) return n;
   if(c%2==0) {
       int result=p(n, c/2) ;
      return result*result;
   }
    else{
       int result =p(n, (c-1) /2) ;
        return n*result*result;
   }
 
  
}
int f(int n,int c) {
    if(n==0) return 0;
    return p(n%10, c) +f(n/10,c);
}
int main()
{ int a=153,c=0;
 while(a!=0) {
    a/=10;
    c++;
 }
  cout<<f(153, c) ;
    return 0;
}