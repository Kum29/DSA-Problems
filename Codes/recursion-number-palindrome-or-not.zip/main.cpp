/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
bool f(int n, int*temp) {
    if(n%10==n) {
       int l=(*temp)%10;
       (*temp)/=10;
       return (n==l) ;
    }
    bool result=(f(n/10, temp) and(n%10==(*temp) %10));
    (*temp)/=10;
    return result;
}
int main()
{
    int n=1231;
    int x=121;
    int*temp=&x;
    cout<<f(n, temp);
    
    return 0;
}
