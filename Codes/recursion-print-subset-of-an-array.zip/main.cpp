/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
#include<vector>
using namespace std;
void f(int*arr,int n, int sum, int idx, vector<int>&a) {
    if(idx==n) {
        a.push_back(sum) ;
        return;
    }
    f(arr,n, sum+arr[idx], idx+1, a) ;
    f(arr,n, sum, idx+1, a) ;
}
int main()
{
  int arr[]={2, 5,4};
  int n=sizeof(arr) /sizeof(arr[0]) ;
  vector<int>a;
  f(arr,n,0,0,a) ;
  for(int j;j<a.size() ;j++) {
      cout<<a[j]<<" ";
  }
    return 0;
}