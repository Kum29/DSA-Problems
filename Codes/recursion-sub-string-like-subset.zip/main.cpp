/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h>
using namespace std;
void f(string &a, int I, string s, vector<string>&b) {
if(I==a.size()){
 b.push_back(s) ;
 return;
}
f(a, I+1, s+a[I], b) ;
f(a, I+1, s, b) ;
}
int main()
{ string a="dok";
  vector<string>b;
  f(a, 0," ",b);
  for(int I=0;I<b.size() ;I++) {
      cout<<b[I]<<" ";
  }
    return 0;
}