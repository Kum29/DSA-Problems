#include<bits/stdc++.h>
using namespace std;
vector<int>f(int *arr,int i,int n, vector<int>v){
    if(i>n) return v;
    return f(arr,i+1,n,v);
    v.push_back(arr[i]);
    return f(arr,i+1,n,v);
}
int main()
{
    int arr[]={1,2,3};
    vector<int>v;
   for(int i=1;i<=8;i++){
      vector<int>vi=f(arr,0,2,v);
      for(int j=0;j<vi.size();j++){
          cout<<vi[j]<<" ";
      }
      cout<<endl;
   }  
   
   
   
   
    return 0;
}
