/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
int f(int*arr, int n, int idx) {
    if(idx==n-1) return arr[idx];
    return(arr[idx]+f(arr,n, idx+1));
}
int main()
{
    int arr[]={1, 2,3,4,5,6};
    int n=sizeof(arr) /sizeof(arr[0]) ;
    int x=f(arr, n, 0) ;
    cout<<x;
    return 0;
}