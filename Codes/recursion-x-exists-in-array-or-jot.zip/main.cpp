/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
bool f(int *arr, int n, int t) {
    if(n==-1) return false;
    if(arr[n]==t) return true;
   return f(arr,n-1,t);
}
int main()
{
int arr[]={1, 3,5,7,0,5,7,6};
int n=sizeof(arr) /sizeof(arr[0]) ;
cout<<f(arr, n-1, 7) ;
    return 0;
}
