/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int min(int x,int y){
    if(x>y) return x;
    else return y;
}
int main()
{
int x,y,z; scanf("%d %d",&x,&y);
z=min(x,y);
printf("%d",z);
    return 0;
}
