/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<string.h>
int main()
{ char str[20];
    puts("Enter a string");
    scanf("%[^\n]s",str);
  //size
  int size=0,k;
  while(str[k]!='\0'){
      size++;
      k++;
  }
  //Reverse
 for(int i=0,j=size-1;i<=j;i++,j--){
     char temp=str[i];
     str[i]=str[j];
     str[j]=temp;
 }
 puts("Reverse strng is: ");
 puts(str);
    return 0;
}
