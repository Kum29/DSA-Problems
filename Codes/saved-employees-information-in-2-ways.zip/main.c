/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<string.h>
int main(){
//  struct employee{
//     int Empno;
//     char JobTitle[15];
//     int Salary;
//     char Name[15];
// } E1,E2;
// E1.Empno = 34; printf("%d\n",E1.Empno);
// E1.Salary=24; printf("%d\n",E1.Salary);
// strcpy(E1.JobTitle,"dsfg"); printf("%s\n",E1.JobTitle);
// strcpy(E1.Name,"fzkl"); printf("%s\n",E1.Name);

// E2.Empno=45; printf("%d",E2.Empno);
// strcpy(E2.JobTitle,"wrre"); printf("%s\n",E2.JobTitle);
// E2.Salary=3445; printf("%d",E2.Salary);
// strcpy(E2.Name,"\ndf");
    
    
  //or
//  typedef struct employee{
//      int Empno;
//      char JobTitle[15];
//      int Salary;
//      char Name[15];
//  } Emp;
//  Emp arr[2];
//  arr[0].Empno=34;
//  arr[0].Salary=24;
//  strcpy(arr[0].JobTitle,"dfs");
//  strcpy(arr[0].Name,"dcgd");
 
//  arr[1].Empno=45;
//  arr[1].Salary=2456;
//  strcpy(arr[1].JobTitle,"dfs");
//  strcpy(arr[1].Name,"dcgd");
 
//  for(int i=0;i<2;i++){
//      printf("E1.Empno%d\n", arr[i].Empno);
//      printf("E1.Salary%d\n",arr[i].Salary);
//      printf("%s\n",arr[i].Name);
//      printf("%s",arr[i].JobTitle);
//  }
 return 0;
}
