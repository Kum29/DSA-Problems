/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{ 
   int arr[]={6,9,3,2,1},s,minidx;
   for(int i=0;i<4;i++){ //i-> 0 to 4 bcoz only 4 passes take place in 5 element array 
       for(int j=i;j<=4;j++){
       s=arr[i],minidx=-1;
       if(s>arr[j]){
         s=arr[j];
         minidx=j;
       } 
       int temp=arr[minidx];
       arr[minidx]=arr[i];
       arr[i]=temp;
       }
   }
   for(int i=0;i<5;i++){
  printf("%d",arr[i]);
   }
    return 0;
}