/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
//using 2 pointers
int main()
{
int arr[]={1,2,3,4,5,8,9,10};
int target=8;
int l=sizeof(arr) ;
for(int i=0;i<l;i++){
  if(arr[i]==arr[l-1]) 
  printf("sjs") ;
  if(arr[i]>arr[l-1]) 
  l--;
  if(arr[i]<arr[l-1]) 
  i++;
}




    return 0;
}
