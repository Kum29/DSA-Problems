#include <bits/stdc++.h>
using namespace std;
bool isBalanced(string str){
    stack<char>st;
    int n=str.size();
    for(int i=0;i<n;i++){
       if(str[i]=='(') 
       st.push(str[i]);
      
        else{
            if (st.size()==0){
            return false;
            }
           else st.pop();
        }
    }
    if(st.size()>0){
    return false;
    }
    else return true;
    
}
int main()
{
    string str="()()";
    cout<<isBalanced(str);
    return 0;
}
