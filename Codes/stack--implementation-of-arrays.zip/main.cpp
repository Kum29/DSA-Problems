#include <bits/stdc++.h>
using namespace std;
//using stack in the name of array. its basically just array
class Stack{
    public:
   int arr[4];
   int idx=1;
   void push(int x){
       if(isflowed()==1){
           cout<<"stack is flowed";
           return;
       }
       arr[idx]=x;
       idx++;
   }
   void top(){
       if(idx<=0) cout<< "-1";
       cout<<endl<<arr[idx-1]<<endl;
   }
   void pop(){
       if(idx<=0) return;
       idx--;
   }
   void display(){
       for(int i=1;i<idx;i++){
           cout<<arr[i];
       }
       cout<<endl;
   }
   void size(){
       cout<<idx<<endl;
   }
   bool isflowed(){
       if(idx==0 || idx>(sizeof(arr)/4)) return true;
       else return false;
    }
};
int main()
{
 Stack *st=new Stack();
 st->push(1);
 st->push(2);
 st->push(3);
 st->display();
 st->pop();
 st->display();
 st->push(4);
 st->display();
 st->top();
 st->display();
 st->size();
 if(st->isflowed()==1) cout<<"stack is flowed";
 st->push(10);
    return 0;
}
