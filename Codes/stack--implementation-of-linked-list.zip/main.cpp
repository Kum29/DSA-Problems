#include <bits/stdc++.h>
using namespace std;
class Node{
    public:
    int val;
    Node *next;
    Node(int data){
        this->val=data;
    }
};
class Stack{
    public:
    Node *head= NULL;
    int size=0;
    
    void push(int z){
        Node *temp=new Node(z);
        temp->next=head;
        head=temp;
        size++;
    }
    void pop(){
        if(head==NULL){
            cout<<"stack is empty";
            return;
        }
        head=head->next;
        size--;
    }
    void top(){
        cout<<"top element is :"<<head->val<<endl;
    }
    void display(){
        Node *agla=NULL;
        Node *prev=NULL;
        Node *cur=head;
        while(cur!=NULL){
            agla=cur->next;
            cur->next=prev;
            prev=cur;
            cur=agla;
        }
        Node *temp=prev;
        while(temp!=NULL){
            cout<<temp->val<<" ";
            temp=temp->next;
        } cout<<endl;
    }
    void s(){
        cout<<"size is: "<<size<<endl;
    }
    void isempty(){
        if(size==0) cout<<"stack is empty";
    }
};

int main()
{
    Stack *st=new Stack();
    st->push(10);
    st->push(11);
    st->push(12);
    st->push(13);
    st->display();
    st->pop();
    st->display();
    st->s();
    st->top();
    st->push(1);
  //  st->pop();st->pop();st->pop();st->pop();
    st->display();
    st->s();
    st->isempty();
    return 0;
}