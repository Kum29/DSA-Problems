#include <bits/stdc++.h>
using namespace std;
void pushbottom(stack<int>s,int top){
    stack<int>rt;
    while(!s.empty()){
        rt.push(s.top());
        s.pop();
    }
    s.push(top);
    while(!rt.empty()){
        s.push(rt.top());
        rt.pop();
    }
    return;
}
void displayrec(stack<int>s){
    if(s.size()==1) return;
    int top=s.top();
    s.pop();
    displayrec(s);
    pushbottom(s,top);//stack- is a type of call by refrence so no need to store it
    cout<<s.top();
}
int main()
{
  stack<int>st; stack<int>rt; stack<int>at;
  int arr[4];
  st.push(4); st.push(3);  st.push(2);  st.push(1);
  //by recursion
 displayrec(st);
 cout<<endl;
 
 //by iteration
 while(!st.empty()){
     rt.push(st.top());
     st.pop();
    }
 while(!rt.empty()){
     at.push(rt.top());
     rt.pop();
    }
 while(!at.empty()){
     st.push(at.top());
     at.pop();
    }
 //while(!st.empty()){
 //    cout<<st.top();
  //   st.pop();
 //   } cout<<endl;
    
 //by arrays
 for(int i=1;i<=4;i++){
     arr[i]=st.top();
     st.pop();
 }
 for(int i=4;i>=1;i--){
     st.push(arr[i]);
 }
  while(!st.empty()){
     cout<<st.top();
     st.pop();
    } cout<<endl;
  
    return 0;
}
