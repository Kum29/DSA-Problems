#include <bits/stdc++.h>
using namespace std;
//void display1(stack<int>s){ //stack is pass by refrence like arrays
 //  while(!s.empty()){
 //     cout<<s.top()<<" ";
  //     s.pop();
  //  } 
//}
void displayrec(stack<int>s){
    if(s.size()==0) return;
    cout<<s.top();
    s.pop();
    displayrec(s);
}
int main()
{
   stack<int>st;
   st.push(1);
   st.push(2);
   st.push(3);
   st.push(4);
   stack<int>rt;
   while(!st.empty()){
       int x=st.top();
       rt.push(x);
       st.pop();
   }
   while(!rt.empty()){
       int z=rt.top();
       st.push(z);
       rt.pop();
    }
    st.push(10);
 //   display1(st);
    displayrec(st);
    return 0;
}

