#include <iostream>
#include <stack>
using namespace std;
int main()
{
    stack<int>st;
    st.push(1);
    st.push(2);
    st.push(3);
    st.push(4);
    int n=3; //remove nth index from top
    stack<int>rt;
    for(int i=n-1;i>=1;i--){
        rt.push(st.top());
        st.pop();
    }
    st.pop();
    while(!rt.empty()){
        st.push(rt.top());
        rt.pop();
    }
    while(!st.empty()){
        cout<<st.top();
        st.pop();
    }
    
      return 0;
}