#include <bits/stdc++.h>
using namespace std;
int main()
{
    stack<int>st; 
  st.push(4); st.push(3);  st.push(2);  st.push(1);
  st.pop(); st.pop(); st.pop(); st.pop(); st.pop(); st.pop();
  while(!st.empty()){
      cout<<st.top();
      st.pop();
  } 
  //underflow- stack is empty, st.pop/st.top gives empty stack exception(stack error)
  //overflow- if actual memory is full & we try to push into stack then overflow happens    
    return 0;
}