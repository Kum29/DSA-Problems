#include <iostream>
#include<stack>
using namespace std;
int main()
{
    stack<int>st;
 //   int n=5;
 //   for(int i=1;i<=n;i++){
 //       int y;
 //       cin>>y;
 //       st.push(y);
//        cout<<st.top()<<" "<<endl;
//    }
st.push(1);
st.push(2);
st.push(3);
st.push(4);
    stack<int>rt;
    while(!st.empty()){
        int x=st.top();
        rt.push(x);
        st.pop();
        cout<<rt.top();
    }
    cout<<endl;
    stack<int>gt;
    while(!rt.empty()){
        int x=rt.top();
        gt.push(x);
        rt.pop();
        cout<<gt.top();
    }
    
    return 0;
}

