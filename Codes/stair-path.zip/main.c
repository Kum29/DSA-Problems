/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
//if we can do single,double jumps
int ways(int n){
    if(n<=2) return n;
    return (ways(n-1))+(ways(n-2));//big to small problem. here considering only 3 steps in place
}
int main()
{ int n; scanf("%d",&n);
printf("%d",ways(n));


//if we can do single,double,triple jumps
int way(int m){
    if(m<=3) return m;
    return (way(m-1))+(way(m-2))+(way(m-3));//big to small problem. here considering only 3 steps in place
}
 int m; scanf("%d",&m);
printf("%d",way(n));


    return 0;
}
