/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<string>
using namespace std;
int main()
{
// string food; //--> i can also write it as string food("dosa");
// cin>>food;
// cout<<food;

//string food;
//food="dosa";
//cout<<food;


//->but
//string food; //-> here as soon as we declare a variable we have to initialise it.
//food("dosa");


//->print an alphabet the number of times using string.
//string food(5,'d');
//cout<<food;


//-> print 2 words when no input taken
//string full_name="kumkum Gowda";
//cout<<full_name;


//->print 2 words when input taken
//string intro;
//getline(cin,intro);
//cout<<intro;


//-> size in the string. reverse of string. print string usimf for loop
//string name="kumkum";
//int length=name.size();
//cout<<length<<endl;
//for(int i=0;i<=length;i++){
//cout<<name[length-i]<<"";//length gets counted from 1. but the position of characters is started from index 0.
//}
//for(int i=0;i<length;i++){
   // cout<<name[i];
//}


//-> caps &, lower case
string first="kumkpm";
string second="Kumkum"; 
int flag=0;
int length=first.size();

//if(first==second){
  //  cout<<",equals";
//} else cout<<"not equal";
//char smal=tolower(second[0]);
//cout<<smal;

//characters in both are same or not.
//for(int i=0;i<length;i++){
    //if(tolower(first[i])!=tolower(second [i])){
     //   flag=1;
     //   break;
   // }
//}
//if(flag==0){
//    cout<<"equal";
//}
//else cout<<"not equal";


//-> convert small case to upper case &vice versa
//char capital=toupper('a');
//cout<<"\n"<<capital<<"\n";
//char small=tolower('F');
//cout<<small;









    return 0;
}
