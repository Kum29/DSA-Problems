'''
Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.
'''

#sequence-list string tuple
#string- sequence of character (text)

'''
string=")$)__)__)3)3}|}|}¥ekkdf"
str1="929393949494"

#indexing
a="wllekd"
  #012345
#-5-4-3-2-1
print(a[3]) #accessing the character at index
#adding "-" is no issue. it also gives same character

#slicing
#a[star_index:stop_index:step=1]
print(a[1:6:3]) #its i>=1 & i<6
print(a[::-1]) #its reverse
print(a[::3])#it skips the no. in  the string & print that.
print(a[:-4:-1])#doesnt include '-4'
'''


a="kumkum"
'''
#mutable-sequence in which we can change the element
#a[2]="a" //string is immutable
l=[1,2,3]
l[1]=100
print(1[:])
'''
'''
#member in sequence(string,list,tuple)
#membership operator
print("a" in "kumkum")
l=[1,2,3]
print(22 in l)
tup=(1,2,3)#they are immutable 
'''

'''
b="100"
c="dkkf1"
d=" "
#string functions
print(a.isalpha()) #a is alphabet?
print(b.isnumeric())
print(c.isalnum())#alphabet & number
print(a.isupper())
print(d.isspace())
print(a.istitle()) #Kumkum is a title case
'''

'''
print(a.upper())#convert lower to upper case.
print(a.swapcase())
a=" kumkum  "
print(a.lstrip())#remove space from left to right.
print(a.rstrip())
a="kumkum"
print("with char",a.rstrip("m"))#remove character from right which is mentioned in bracket
print(a.lstrip("k"))
print("-".join(a)) #put this in between string

b="kumkum.gowda"
print(b.partition("a")) #partition return typle(left, middle, right)
print(b.split("."))
'''


name="kumkum gowda"
print (name.split(" "))
firstname =name.split()[0]
lastname=name.split()[1]
print("first name is ",firstname)
print("last name is ",lastname)



