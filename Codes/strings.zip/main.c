/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{ //hello world
    char arr[]={'h','e','l','l','o',' ','w','o','r','l','d','\0'};
   for(int i=0;i<11;i++) printf("%c\n",arr[i]);
   
   char ch='\0'; 
   int x=0;
   char a=(char)x;//a->'\0'
   printf("%c",a);
   
   
   int i=0;
   while(arr[i]!='\0'){
       printf("%c",arr[i]);
       i++;
   }
   //diffeent type of string
   char brr[]="djhdjdfj jdfjjdfnjf";
   int j=0;
   while(brr[j]!='\0'){
       printf("%c",brr[j]);
       j++; 
   }
    return 0;
}

