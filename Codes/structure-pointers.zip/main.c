/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<string.h>
int main()
{ typedef struct pokemon{
       int hp;
       int speed;
       char tier;
       char name[15];
   } pokemon;
pokemon pickachu;
pickachu.hp=50;
pickachu.speed=100;
pickachu.tier='A';
strcpy(pickachu.name,"pickachu");
    
pokemon*x=&pickachu;
printf("%p\n",&pickachu.hp);
printf("%p\n",&pickachu.speed);
printf("%p\n",&pickachu.tier);
printf("%p\n",&pickachu.name);

printf("%p",x);
return 0;
}
