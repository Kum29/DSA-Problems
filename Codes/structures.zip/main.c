/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl, C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog. Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main(){
struct pokemon{ //user defined data type
int hp;
int speed;
char tier;
};
struct pokemon pickachu;
pickachu.hp=50;
pickachu.speed=100;
pickachu.tier='A';
  
struct pokemon mewtwo;
mewtwo.hp=100;
mewtwo.speed=200;
mewtwo.tier='G';

return 0;
}